import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoryExchangeRatesComponent } from './history-exchange-rates.component';

describe('HistoryExchangeRatesComponent', () => {
  let component: HistoryExchangeRatesComponent;
  let fixture: ComponentFixture<HistoryExchangeRatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HistoryExchangeRatesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoryExchangeRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
