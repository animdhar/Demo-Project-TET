import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../api-service.service';

@Component({
  selector: 'app-history-exchange-rates',
  templateUrl: './history-exchange-rates.component.html',
  styleUrls: ['./history-exchange-rates.component.css']
})
export class HistoryExchangeRatesComponent implements OnInit {

  userDate!: Date;
  errorMessage: string = '';
  currencyList: any[] = [];
  filteredList: any[] = [];
  today = new Date();
  filterBy!: string;
  constructor(private currencyService: ApiServiceService) { }

  ngOnInit(): void {
  }

  dateRun(x: Date) {
    this.currencyList = [];
    this.currencyService.getHistoryRates(x).subscribe({
      next: x => {
        this, this.errorMessage = '';
        console.log(x);
        for (let i in x.rates) {
          this.currencyList.push([i, x.rates[i]])
        }
      },
      error: err => this.errorMessage = 'Please Enter a Valid Date '
    })
    console.log(this.currencyList);
  }

  filterList(filter: string): void {
    this.filteredList = [];
    for (let i = 0; i < this.currencyList.length; i++) {
      if (this.currencyList[i].includes(filter.toUpperCase())) {
        this.filteredList.push(this.currencyList[i])
      }

    }
    console.log(this.filteredList)
  }
}

