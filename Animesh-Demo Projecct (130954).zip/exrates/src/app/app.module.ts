import { FormsModule } from '@angular/forms';
import { HistoryExchangeRatesComponent } from './all-exchange-rates/history-exchange-rates.component';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AllExchangeRatesComponent } from './all-exchange-rates/all-exchange-rates.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { HttpClientModule } from '@angular/common/http';
import { ExchangeRatesComponent } from './all-exchange-rates/exchange-rates.component';

@NgModule({
  declarations: [
    AppComponent,
    AllExchangeRatesComponent,
    WelcomeComponent,
    CourseDetailsComponent,
    ExchangeRatesComponent,
    HistoryExchangeRatesComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path :"", component: WelcomeComponent},
      {path: "welcome", component: WelcomeComponent},
      {path: 'rates', component: ExchangeRatesComponent,
    children: [
      {path : 'latest', component : AllExchangeRatesComponent},
      {path : 'history',component : HistoryExchangeRatesComponent}
    ]},
      {path: 'courses', component: CourseDetailsComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
