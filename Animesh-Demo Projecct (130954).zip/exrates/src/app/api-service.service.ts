import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  baseUrl = "http://api.exchangeratesapi.io/v1/";
  accessKey = "37ce0860529d410c23dd6f1de7499034";

  constructor( private http : HttpClient) { }

  getRates () : Observable <any>{
    let url = `${this.baseUrl}latest?access_key=${this.accessKey}`; 
    return this.http.get<any>(url);
  }

  getHistoryRates ( date: Date) : Observable <any>{
    let url = `${this.baseUrl}${date}?access_key=${this.accessKey}`;
    return this.http.get<any>(url);
  }
}
