export interface Courses {
    courseId : number,
    courseName : string,
    coursePrice : number
}