import { ApiServiceService } from './../api-service.service';
import { CourseService } from './../course.service';
import { Component, OnInit, Injectable } from '@angular/core';
import { Courses } from './course';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {

  courseList: Courses[] = [];
  currencyList: any[] = [];
  basePrice = 'EUR';
  wantedCurrency: string = '';
  desiredCurrency: any[] = [];
  priceIndex!: number;
  errorMessage: string = '';
  userDate!: Date;
  reference: string = '';

  constructor(private cservice: CourseService,
    private currencyService: ApiServiceService) { }


  ngOnInit(): void {
    this.clearFilter();
  }

  updatePrice(filter: string): void {
    this.desiredCurrency = [];
    this.currencyList = [];
    this.clearFilter();
    this.reference = 'Price updated as of Todays Price Index';
    this.currencyService.getRates().subscribe({
      next: x => {
        console.log(x);
        for (let i in x.rates) {
          this.currencyList.push([i, x.rates[i]])
        }
        this.displayUpdate(this.currencyList, filter)
      },
      error: err => console.log(err)
    })

  }



  displayUpdate(list: any[], filter: string): void {
    this.errorMessage = '';

    list.forEach(x => {
      if (x.includes(filter.toUpperCase())) {
        this.desiredCurrency.push(x);
      }
    })
    if (this.desiredCurrency.length == 0) {
      this.errorMessage = 'Please enter a valid currency'
    }
    else {
      this.errorMessage = '';
      this.desiredCurrency.forEach(x => {
        this.basePrice = x[0];
        this.priceIndex = x[1];
        // return;
        console.log(this.desiredCurrency)
        this.courseList.forEach(x => {
          x.coursePrice *= this.priceIndex;
          console.log(x.coursePrice);
        })
      })
    }

  }

  getBackdatedPrice(filter: string, date: Date): void {
    this.desiredCurrency = [];
    this.currencyList = [];
    this.clearFilter();
    this.reference = `Price updated as per ${date} Price Index`;
    this.errorMessage = '';
    if (filter == '') {
      this.errorMessage = 'Please Enter a Currency';
      console.log(this.errorMessage);
    }
    else{
      this.currencyService.getHistoryRates(date).subscribe({
        next: x => {
          console.log(x);
          for (let i in x.rates) {
            this.currencyList.push([i, x.rates[i]])
          }
          this.displayUpdate(this.currencyList, filter)
        },
        error: () => this.errorMessage = 'Please enter a valid date'
      })
    }
    }
 

  clearFilter(): void {
    this.reference = '';
    this.errorMessage = '';
    this.basePrice = 'EUR';
    this.cservice.getCourses().subscribe({
      next: x => {
        this.courseList = x;
      }
    })
    }
}
