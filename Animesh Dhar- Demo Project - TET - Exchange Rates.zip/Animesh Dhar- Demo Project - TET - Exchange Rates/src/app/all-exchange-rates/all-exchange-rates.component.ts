import { ApiServiceService } from './../api-service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-exchange-rates',
  templateUrl: './all-exchange-rates.component.html',
  styleUrls: ['./all-exchange-rates.component.css']
})
export class AllExchangeRatesComponent implements OnInit {

  currencyList: any[] = [];
  private _FilterBy! :string;
  constructor(private currencyService: ApiServiceService) { }

  ngOnInit(): void {
    this.currencyService.getRates().subscribe({
      next: x => {
        for (let i in x.rates) {
          this.currencyList.push([i, x.rates[i]])
        }
      }
    })
  }

 

}
