import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllExchangeRatesComponent } from './all-exchange-rates.component';

describe('AllExchangeRatesComponent', () => {
  let component: AllExchangeRatesComponent;
  let fixture: ComponentFixture<AllExchangeRatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllExchangeRatesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllExchangeRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
