import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Courses } from './course-details/course';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private courseUrl = 'assets/courses.json';
  constructor(private http : HttpClient) { }

  getCourses() : Observable<Courses[]>{
    return this.http.get<Courses[]>(this.courseUrl);
  }
}
